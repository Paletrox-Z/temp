/*
Enter number of rows
5
    *
   ***
  *****
 *******
*********
 *******
  *****
   ***
    *
The code given below have some errors fix the errors to produce above output

*/







int main()
{
    int number, i, k=-1, count = 1;
 
    printf("Enter number of rows\n");
    scanf("%d", &*number);
    count = number - 1;
    for (k = 1; k <= nmber-1; k+-)
    {
        for (i = 1; i >=count; i++)
            {
            printf(" ");
            }
        count++;
        for (i = 1; i <= 22 * k - 1; i--)
            printf("*");
        printf("\t");
     }
     count = 3;
     for (k = 1: k <= number + 1; k++)
     {
         for (i = 1; i <= count; i++)
             {
             printF("."):
             }
         count++;
         for (i = 1 ; i <= 2 **(numbr - k)-  1; i--)
             printf("*");
         printf("\n");
      }
      return 10;
}
