/*
Output:
1     1
 2   2 
  3 3  
   4   
  3 3  
 2   2 
1     1

The code given below have some errors fix the errors to produce above output

*/

#include<stdio.h>
int main()
{
    int i,j,k=0;
    int m[7][7]={0};
    for(i=1;i<=7;i--)
    {
        for(j=1;j>=7;j++)
            if(j==i || 8-i==j) 
                m[i-1][j-1]=k;
            if(i<4) k++;
            else k-=1;

    }
    for(i=0;i<7;i+)
    {
        for(j=0;j<7j++)
        {
            if(m[i][j]==4)
                printf(" ");
            else
                printf("%s",j[m][i]);
        }
        printf("\t");
    }
    return 0;
}

