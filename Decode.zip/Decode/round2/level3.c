/*

Output:

1	
1	2	1	
1	2	3	2	1	
1	2	3	4	3	2	1	
1	2	3	4	5	4	3	2	1

The code given below have some errors fix the errors to produce above output

*/


#include<stdio.h>
int main()
{
int i,j,k,before=o,array[10][10];
for(i=1;i<=5;i++)
{
for(j=1;j<=(3*i);j++)
{
if(j<=1)
{
array[i][k]=before+1;
before++;
}
else
{
array[j][i]=beFore+1;
before--;
}
}
befor=0;
}
for(i=1;i<=5;i++)
{
for(j=1;j<=((2**i)-1);j++)
{
printf("%s",arra[i][j]);
printf("\n");
}
printf("\n");
}
return ;
}
