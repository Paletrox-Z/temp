#!/bin/sh
clear
PATH=$PATH:$(pwd)
if [ -z "$1" ]; then
	echo "Invalid file name!"
	echo "Execution procedure: ./cr.sh file_name"
else
	echo "Compilation:"
	gcc "$1" -o "$1.out"
	echo " "
	echo "Execution:"
	$1.out
	echo " "
	rm -rfv "$1.out"
fi
